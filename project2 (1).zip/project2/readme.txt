*******************************************************************
*    Name:           Chris George
*    Major:          Computer Science
*    Course:         CPSC 237 – Data Structures (Section 010)
*    Instructor:     Dr. Hussain
*    Project:        Project 2 
*    Date:           11-Nov-2025
*******************************************************************

COMPILE COMMAND (Code compiles successfully):
  g++ p2.cpp core.cpp functions.cpp printers.cpp

RUN COMMAND:
  ./a.out

-------------------------------------------------------------------
Data Structure Choices and Justifications
-------------------------------------------------------------------

The data structures that I choose and where I implemented them are 
discussed below. 

1. vector<Transaction>
  I used this to store every transaction line from the file. This is like 
  the simple dynamic array structure we learned in class and it allows 
  stable sorting by date and processing.

2. vector<StockLots>
  This holds all stocks the trader interacted with and stores stocks in 
  the order they first appear in the file allowing for stable sorting. 
  I choose a vector for this because we have covered vectors thoroughly and 
  they allow simple linear searching.

3. vector<Lot>
  This represents the “stack” of purchase lots. LIFO behavior 
  is naturally and easily implemented using push_back() and pop_back()
  which is why I choose that. This matches the problem requirement to 
  track the most recent purchase still available.

All of these choices allow simple iteration through transactions,
efficient LIFO tracking of share lots, natural grouping of stock 
symbols, and clean support for generating the portfolio and advisory 
tables.

-------------------------------------------------------------------
Program Organization
-------------------------------------------------------------------

p2.cpp
  - Main driver of the program
  - Calls the core functions to load, process, and print results

model.h
  - Defines all data structures used throughout the program:
    - Transaction, Lot, StockLots, PortfolioRow, AdvisoryRow

functions.cpp/h
  - Contains basic helper functions...
    - priceToCents(), moneyString(), isUpperDigitString() errorExit()
  - These functions simplify validation and formatting

core.cpp/h
  - Implements the main processing logic...
    - loadTransactions(): reads in the data
    - buildLots(): applies Buy/Sell rules using LIFO
    - buildPortfolio(): makes the portfolio summary table
    - buildAdvisory(): makes the advisory table

printers.cpp/h
  - Handles all output
  - Draws formatted tables for...
    - All Transactions
    - Portfolio
    - Advisory Table
  - Keeps main() and logic functions free of input and output



